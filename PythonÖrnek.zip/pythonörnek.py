# 0 GiRiLENE KADAR GiRiLEN SAYiLARi TOPLAYiP, TOPLAM VE ORTALAMASiNi EKRANA YAZDiRAN PROGRAM

print("Sayilari giriniz.")
Toplam = 0
Ortalama = 0
Sayi = 1
Sayac = 0
while True:
    alinanSayi = int(input(f"Sayi {Sayi} = "))
    if alinanSayi == 0 and Sayi == 1:
        print("Sayi 0 ile baslayamaz")
        break
    Sayi += 1
    Sayac += 1
    Toplam = Toplam + alinanSayi
    if alinanSayi != 0:
        Ortalama = Toplam / Sayac
    if alinanSayi == 0:
        print("Sayilarin toplami =", Toplam)
        print("Sayilarin Ortalamasi =", Ortalama)
        break
