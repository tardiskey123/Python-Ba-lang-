MuhammetHesap = {
    "ad": "Muhammet c",
    "hesapNo": "170710032",
    "bakiye": 9000,
    "yedekBakiye": 3000
}

toplamBakiye = MuhammetHesap['bakiye'] + MuhammetHesap["yedekBakiye"]


def paracek(hesap, miktar):
    print(f"Merhaba {MuhammetHesap['ad']}")
    print(f"Bakiyeniz = {MuhammetHesap['bakiye']}")
    print(f"İstediğiniz para = {miktar}")
    if MuhammetHesap['bakiye'] > miktar:
        print("Para Veriliyor. Çekilen Para =", miktar)
        print("Kalan para =", MuhammetHesap['bakiye'] - miktar)
    if miktar > MuhammetHesap['bakiye'] :
        print("Paranız yetersiz")
        yedekBakiye = int(input("Yedek bakiye kullanılsın mı?\n1-Evet\n2-Hayır\n"))
        if yedekBakiye >2:
            print("Yanlış komut girildi.Tekrar Deneyiniz")
            exit()
        if yedekBakiye == 1:
            print(f"Bakiye Toplamı = {toplamBakiye}")
            if toplamBakiye > miktar:
                print("Para veriliyor")
                print("Kalan para =", toplamBakiye - miktar)
        if yedekBakiye == 2:
            print("Çıkış Yapılıyor")
            exit()
    else:
        print("Para hala yetersiz")




paracek(MuhammetHesap, 10000)
