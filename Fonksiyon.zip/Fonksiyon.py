# 4- Kendisine gönderilen bir sayının tam bölenlerini bir liste şeklinde döndürünüz.


def bölen(sayilar):
    dizi = []
    for sayac in range(sayilar):
        sayac += 1
        if sayac % 2 == 0:
            dizi.append(sayac)
    return dizi


alinanSayi = int(input("Sayı giriniz = "))
sonuc = bölen(alinanSayi)
print(sonuc)
